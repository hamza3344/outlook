﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace outllok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Outlook._Application olApp = (Outlook._Application)new Outlook.Application();
            Outlook.NameSpace mapins = olApp.GetNamespace("MAPI");
            string profile = "";
            mapins.Logon(profile, null, null, null);
            CreateYearlyAppointment(olApp, "Birthday", "MY Friend BIrthday", new DateTime(dateTimePicker1.Value.Year, dateTimePicker1.Value.Month, dateTimePicker1.Value.Day, 7, 0, 0));

        }
        static void CreateYearlyAppointment(Outlook._Application olApp,string reminderComent,string subject,DateTime dt)
        {
            Outlook._AppointmentItem apt = (Outlook._AppointmentItem)olApp.CreateItem(Outlook.OlItemType.olAppointmentItem);
            apt.Subject = subject;
            apt.Body = reminderComent;
            apt.Start = dt;
            apt.End = dt.AddHours(1);
            apt.ReminderMinutesBeforeStart = 60 * 24 * 3 * 1;//3 days
            apt.BusyStatus = Outlook.OlBusyStatus.olTentative;
            apt.AllDayEvent = false;
            apt.Location = "";
            Outlook.RecurrencePattern myPattern = apt.GetRecurrencePattern();
            myPattern.RecurrenceType = Outlook.OlRecurrenceType.olRecursYearly;
            apt.Save();
        }
    }
}
